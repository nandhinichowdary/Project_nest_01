# SENTIMENTAL_ANALYSIS
Sentimental analysis using Python
